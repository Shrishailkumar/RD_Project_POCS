package com.soni.device.connector.constant;

public class AppConstant {

    public static final String BINARY_TOPIC = "/topic/binary-messages";

    public static final String PUSH_TO_ADMIN = "/push-to-admin";

    public static final String PUSH_TO_AGENT = "/push-to-agent";


}
